<?php


class Development extends CI_Controller
{
	public function index()
	{
		
		$this->load->model('devmodel');
		$results = $this->devmodel->getdata();
		$data['welcome'] = $results;
		$this->load->view('dev/index',$data);
		
	}

	public function insert()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules(
			'title', 
			'Username', 
			'trim|required|min_length[2]|max_length[20]'
		);

        $this->form_validation->set_rules(
        	'body', 
        	'Password', 
        	'trim|required|min_length[1]'
        );
        $this->load->view('dev/index');

		if ($this->form_validation->run()) {

			echo $title = $this->input->post('title');
			echo $body = $this->input->post('body');
			$this->load->model('devmodel');
			$this->devmodel->
			
		}

		else
		{
			$this->session->set_flashdata('login_failed', 'Invalid Username/password');
		}
	}
}