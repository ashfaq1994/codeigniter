<?php include('public_header.php'); ?>
<div class="container">
	<table class="table mt-5">
		<thead>
			<th>Sl.no</th>
			<th>Title</th>
			<th>Action</th>
		</thead>
		<tbody>
			<?php  if (count($articles)) : ?>
        	<?php foreach ($articles as $article) :   ?>
			<tr>
				<td><?php ?></td>
				<td><?php echo $article->title; ?></td>
				<td>
					<button class="btn btn-info">Edit</button>
					<button  class="btn btn-danger">Delete</button>
				</td>
			</tr>
		<?php endforeach; ?>
		<?php else: ?>
			<tr colspan="3">
			<?php echo "No record found."; ?>
			</tr>
		<?php endif; ?>
		</tbody>
	</table>
</div>
<?php include('public_footer.php'); ?>