

<?php include('public_header.php'); ?>
<div class="section___form">
			<div class="container">
				<div class="row">
					<!--- coloumn -->
					<div class="col-md-6">
						<div class="form__heading mt-5">
							<h2 class="display-4 text-uppercase bg-faded">
							Sign-in
							</h2>
	<div class="error_message p-2">
<?php  if ($error = $this->session->flashdata('login_failed')) : ?>
				<div class="alert alert-danger" role="alert">
				 <?= $error ?>
	</div>
              <?php endif; ?>
							</div>
							<!-- <form action="#"> -->
								<?php echo form_open('login/admin_login',array('class' => 'form', 'id' => 'form-val')); ?>
								<div class="form-group">
									<label for="email1">UserName</label>
									<?php echo form_input(array(
                                      'name' => 'username',
                                      'id' => 'username',
                                      'class' => 'form-control',
                                      'placeholder' => 'Enter User Name',
                                      'value' => set_value('username')
									)); ?>
									<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
									<?php echo form_error('username');?>
								</div>
								<div class="form-group">
									<label for="password1">Password</label>
									<?php echo form_password(array(
                                   'name' => 'password',
                                   'id' => 'password',
                                    'class' => 'form-control',
                                    'placeholder' => 'Enter Password',
                                    'value' => set_value('password')
									)); ?>
									<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
									<?php echo form_error('password');?>
								</div>								

								<div class="form-group">
									<?php echo form_submit('loginsubmit', 'Submit', array('class'=> 'btn btn-info')); ?>
									<?php echo form_reset('reset', 'Reset', array('class' => 'btn btn-danger')); ?>
									<!-- <button class="btn btn-info" type="submit">SUBMIT</button> -->
								</div>								
								<?php echo form_close(); ?>

								<!-- ?php echo validation_errors(); ?> -->
						</div>
					</div>
				</div>

			</div>
		</div>
<?php include('public_footer.php') ?>