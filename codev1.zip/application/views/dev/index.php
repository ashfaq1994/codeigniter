<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>development</title>
	<?php echo link_tag('assets/css/bootstrap.css'); ?>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-6 offset-1">
				<div style="border:1px solid red";>
<div class="form mt-5">
	<!--- start -->

	<div class="error_message p-2">
<?php  if ($error = $this->session->flashdata('login_failed')) : ?>
				<div class="alert alert-danger" role="alert">
				 <?= $error ?>
	</div>
              <?php endif; ?>
	</div>
	<!-- end -->
	<?php echo form_open('development/insert'); ?>
 <div class="form-group">
 <label for="name">Title</label>
 		<?php echo
form_input(array(
 	'name' => 'title',
 	'class' => 'form-control',
 	'placeholder' => 'Enter User Name',
 	'value' => set_value('title')));
	 ?>
	 <?php echo form_error('title');?>
 </div>

  <div class="form-group">
 <label for="name">Title</label>
 		<?php echo
form_input(array(
 	'name' => 'body',
 	'class' => 'form-control',
 	'placeholder' => 'Enter User bdoy',
 	'value' => set_value('body')));
	 ?>
 </div>
 <div class="form-group">
 	<?php echo form_submit(
 		'mysubmit', 'Submit Post!',
 		array('class' => 'btn btn btn-info')
 	); ?>
 </div>
  <?php echo form_close(); ?>
</div>


				</div>
			</div>
			<?php echo validation_errors(); ?>

		</div>
	</div>
	<script src="<?php echo base_url('assets/js/jquery.js'); ?>"></script>	
	<script src="<?php echo base_url('assets/js/script.js'); ?>"></script>	
</body>
</html>