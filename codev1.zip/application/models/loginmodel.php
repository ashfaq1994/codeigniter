<?php

class LoginModel extends CI_Model
{
	public function login_valid($username,$password)
	{
		$this->load->database();
		$query = $this->db->get_where('users', array('username' => $username, 'password' => $password));
		 //$q = $this->db->query('SELECT * FROM users WHERE username  = $username AND password = $password');
		// $q = $this->db->get_where(array('username'=>$username,'password'=>$password))->get('users'));
		 if ($query->num_rows()) {
            // echo "<pre>";
            // print_r($q->result()); exit;
		 	 return $query->row()->user_id;

		 	//return true;

		 } else
		 {
         return false;
		 }
	}
}