<?php

class Devmodel extends CI_Model
{
	function getdata()
	{
		$this->load->database();
		$query  = $this->db->get('article');
		return $query->result();
	}

	function insert_data($data)
	{

	}
}