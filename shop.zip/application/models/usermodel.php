<?php

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Usermodel extends CI_Model
{
	function get_users_data($data=array(),$where)
	{
         $result = $this
         ->db->
         insert($where,$data);
         return $result;
	}

	function select_users_data($email,$password)
	{
		//array('email' => $email,'password' = md5($password));
	 $result =  $this->db->get_where('users',array('email' => $email,'password' => md5($password)))->row();

	 return $result;
	}

}