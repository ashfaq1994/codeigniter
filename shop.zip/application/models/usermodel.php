<?php

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Usermodel extends CI_Model
{
	public function get_users_data($data=array(),$where)
	{
         $result = $this
         ->db->
         insert($where,$data);
         return $result;
	}

	public function select_users_data($email,$password)
	{
		//array('email' => $email,'password' = md5($password));
	 $result =  $this->db->get_where('users',array('email' => $email,'password' => md5($password)))->row();

	 return $result;
	}

	public function profile_update($data=array(),$id)
	{
		$result = $this
		->db
		->where('id',$id)
		->update('users',$data);

		$this->session->userdata($data);

		return $result;
	}

	public function where_mail($email,$id)
	{
   $result =  $this->db->get_where('users',array('email' => $email,'id' => $id))->row();

	 return $result;
	}


}