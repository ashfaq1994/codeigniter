<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Loginmodel extends CI_Model
{

	
	public function logincheck($email,$password)
	{
		 $result =  $this->db->get_where('admin',array('email' => $email,'password' => md5($password)))->row();

	    return $result;
	}

	function update_date($id,$date=array())
	{
		$result = $this
		->db
		->where('id', $id)
		->update('admin',$date);

		return $result;
	}

	function register($data=array())
	{
		return $this->db->insert('admin',$data);
	}

}