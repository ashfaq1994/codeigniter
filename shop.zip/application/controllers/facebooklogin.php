<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Facebooklogin extends CI_Controller
{
	
    private $fb;
	public function __construct()
	{
		parent:: __construct();
		$this->load->library('facebookSDK');
		$this->fb=$this->facebooksdk;
	}
	public function index()
	{
		$this->load->library('facebookSDK');
		$this->fb=$this->facebooksdk;
		$ab = "http://localhost/shop/facebooklogin/callback";
		$data['url']=$this->fb->getLoginUrl($ab);
		$this->load->view('front/front',$data);

	}

	public function callback()
	{
         $abc =  $this->fb->getAccessToken();
         $data  = $this->fb->getUserData();
         print_r($data);
	}
}