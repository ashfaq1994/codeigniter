<?php

class Login extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
  
    } 

    public function is_logged_in()
    {
        $user = $this->session->userdata('user');
        return isset($user);
    }


	public function index()
	{
		if ($this->is_logged_in()) {
			
			redirect('dashboard');
		}
		
		$this->load->view('back/index');
	}

	public function logincheck()
	{ 
         $this->form_validation->set_rules('email', 'E-mail', 'trim|required');
         $this->form_validation->set_rules('password', 'Password', 'trim|required');
         $this->form_validation->set_error_delimiters(
     	'<div class="alert alert-danger"><strong>','</strong></div>');

         if ($this->form_validation->run()) {
            
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $this->load->model('loginmodel');
         	$result = $this->loginmodel->logincheck($email,$password);

         	if ($result) {
         		
         		$user = $this->session->set_userdata('user',$result);
         		$this->session->set_userdata('login',true);

                $date = array('date' => date('d-m-y H-I-s'));
         		$result = $this->loginmodel->update_date($result->id,$date);

         		redirect('dashboard');
         	}
         	else
         	{
         		$this->session->set_flashdata('test','<div class="alert alert-danger"><strong>Username and password not match</strong></div>');
         		redirect('login');
         	}



         } else {

          $errors = validation_errors();
         	$this->session->set_flashdata('test',$errors);
         	redirect('login');
         	
         }
	}

	public function dashboard()
	{
		if (!$this->is_logged_in()) {
			redirect('login');
		}
	
	   $this->load->view('back/dashboard');
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login');
	}

	public function register()
	{
		if ($this->is_logged_in()) {
			
			redirect('dashboard');
		}

	 $this->load->view('back/register');
		
	}

	public function register_data()
	{
		$this->form_validation->set_error_delimiters(
     	'<div class="alert alert-danger"><strong>','</strong></div>');
		if ($this->form_validation->run('register')) {
			
		 $name = $this->input->post('name');
		 $email = $this->input->post('email');
		 $password = $this->input->post('password');
		 $data = array(
		 	'name' => $name, 
		 	'email' => $email , 
		 	'password' => md5($password), 
		 );

			$this->load->model('loginmodel');
			$result = $this->loginmodel->register($data);
			if ($result) {
				$this->session->set_flashdata('register', '<div class="alert alert-success"><strong>Register Success</strong></div>');
				redirect('register');
			}
			else
			{
                 $this->session->set_flashdata('register', '<div class="alert alert-danger"><strong>Register Success</strong></div>');
			}
		} else {
			
            $errors = validation_errors();
         	$this->session->set_flashdata('register',$errors);
         	redirect('register');

		}
	}

	public function gettest($id,$name)
	{
		echo $id . ' ' .$name;
	}

}