<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Users extends CI_Controller
{
	public function index()
	{
		
	}

	public function register()
	{
		$this->load->library('form_validation');
	    $this->form_validation->set_rules(
        'username', 'Username',
        'required|min_length[5]|max_length[12]|is_unique[users.username]',
        array(
                'required'      => 'You have not provided %s.',
                'is_unique'     => 'This %s already exists.'
        ));
	    $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[users.email]');
	    $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[1]');
	    $this->form_validation->set_rules('passconf', 'Password Confirmation', 'trim|required|matches[password]');
         $this->form_validation->set_error_delimiters(
     	'<div class="alert alert-danger"><strong>',
     	'</strong></div>');

	    if ($this->form_validation->run()) {
	    	
	    	$username = $this->input->post('username');    
	    	$email = $this->input->post('email');	    
	    	$password = $this->input->post('password');
	    	$dates = date('d-m-y');

	    	$data = array(
	    		'username' => $username, 
	    		'email' => $email, 
	    		'password' => md5($password), 
	    		'user_avatar' => 'assets/images/uploads/ava4.jpg', 
	    		'member_id' => 1, 
	    		'date' => $dates, 
	    	);
	    	$this->load->model('usermodel');
	    	$results = $this->usermodel->get_users_data($data,'users');
	    	if ($results) 
	    	{

	    	$this->session->set_flashdata('info','<div class="alert alert-danger"><strong>Welcome To Movies</strong></div>');
	    		    
              redirect('front');
	        }else
	        {
	        	 redirect('error');
	        }     
	    }

	    else
	    {
	    	$this->load->view('front/front');
	    }
	}

	public function login()
	{
		
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$this->load->model('usermodel');
		$soure = $this->usermodel->select_users_data($email,$password);
		print_r($soure);
		if ($soure) {
			$this->session->userdata('status',true);
			$this->session->userdata('user',$soure);
		 $grit = "<script>
			jQuery(document).ready(function($) {
			'use strict';
			$.gritter.add({
			title: 'Hello $soure->username',
			text: 'This will fade out after a certain amount of time.',
			sticky: true,
			class: 'with-icon check-circle success',
			time: '',
			});
			return false;
			});
			</script>";
			$this->session->set_flashdata('grit',$grit);
			redirect('front');
		}
	}

}