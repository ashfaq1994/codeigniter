<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Users extends CI_Controller
{
	public function index()
	{
		$this->load->view('front/front');
	}

	public function register()
	{
		$this->load->library('form_validation');
	    $this->form_validation->set_rules(
        'username', 'Username',
        'required|min_length[5]|max_length[12]|is_unique[users.username]',
        array(
                'required'      => 'You have not provided %s.',
                'is_unique'     => 'This %s already exists.'
        ));
	    $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[users.email]');
	    $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[1]');
	    $this->form_validation->set_rules('passconf', 'Password Confirmation', 'trim|required|matches[password]');
         $this->form_validation->set_error_delimiters(
     	'<div class="alert alert-danger"><strong>',
     	'</strong></div>');

	    if ($this->form_validation->run()) {
	    	
	    	$username = $this->input->post('username');    
	    	$email = $this->input->post('email');	    
	    	$password = $this->input->post('password');
	    	$dates = date('d-m-y H-I-s');

	    	$data = array(
	    		'username' => $username, 
	    		'email' => $email, 
	    		'password' => md5($password), 
	    		'user_avatar' => 'assets/images/uploads/ava4.jpg', 
	    		'member_id' => 1, 
	    		'date' => $dates, 
	    	);
	    	$this->load->model('usermodel');
	    	$results = $this->usermodel->get_users_data($data,'users');
	    	if ($results) 
	    	{

	    	$this->session->set_flashdata('info','<div class="alert alert-danger"><strong>Welcome To Movies</strong></div>');
	    		    
              redirect('front');
	        }else
	        {
	        	 redirect('error');
	        }     
	    }

	    else
	    {
	    	$this->load->view('front/front');
	    }
	}

	public function login()
	{
	   $this->load->library('form_validation');
	   $this->form_validation->set_rules('email', 'E-mail', 'trim|required|valid_email');
	   $this->form_validation->set_rules('password', 'Password', 'trim|required');
	   $this->form_validation->set_error_delimiters(
     	'<div class="alert alert-danger"><i class="fa fa-remove"></i>&nbsp;<strong>',
     	'</strong></div>');
	   $this->load->model('usermodel');
	   if ($this->form_validation->run()) {

	   	$email  = $this->input->post('email');
	   	$password = $this->input->post('password');
	   	$result = $this->usermodel->select_users_data($email,$password);
	   	if ($result) {
	   		
	   /*	echo '<div class="alert alert-success"><i class="fa fa-check"></i>&nbsp;<strong>Check Username password</strong></div>';*/
	   echo "a";
	   		$this->session->set_userdata('status',true);
			$this->session->set_userdata('user',$result);
		 // $grit = "<script>
			// jQuery(document).ready(function($) {
			// 'use strict';
			// $.gritter.add({
			// title: 'Hello $result->username',
			// text: 'This will fade out after a certain amount of time.',
			// sticky: true,
			// class: 'with-icon check-circle success',
			// time: '800',
			// });
			// return false;
			// });
			// </script>";
			// $this->session->set_flashdata('grit',$grit);
			//redirect('front');
	   	}
	   	else
	   	{
	   		echo '<div class="alert alert-danger"><i class="fa fa-remove"></i>&nbsp;<strong>Check Username password</strong></div>';
	   	}

	   } 

	   else {
	   echo validation_errors();
	   }
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url());
	}

	public function profile()
	{
		$this->load->view('front/profile');

	}

	public function profile_update()
	{
		$this->load->library('form_validation');
	    $this->form_validation->set_rules('username', 'E-mail', 'trim|required');
	    $this->form_validation->set_rules('email', 'E-mail', 'trim|required');
        $this->form_validation->set_error_delimiters('<div class="alert alert-danger"><strong>','</strong></div>');

	    if ($this->form_validation->run()) {

    	    $config['upload_path']          = './uploads/';
            $config['overwrite']          = true;
            $config['detect_mime']          = true;
            $config['allowed_types']        = 'jpeg|jpg|png';
            $config['max_size']             = 1024;
            $config['max_width']            = 250;
            $config['max_height']           = 250;

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('userfile')) {
            	$uploads = $this->upload->data();
            	$file_name = $uploads['file_name'];
            	$path = 'uploads/'.$file_name.'';

            $this->session->set_flashdata('upload', '<div class="alert alert-danger"><strong>image error Updated</strong></div>');
        
	    	$username = $this->input->post('username');    
	    	$email = $this->input->post('email');

	      	$this->load->model('usermodel');
            $user = $this->session->userdata('user');
           $data = array(
	    		'username' => $username, 
	    		'email' => $email, 
	    		'user_avatar' => $path,
	    	);
	    	$result = $this->usermodel->profile_update($data,$user->id);
			if ($result) {

			$mail = $this->usermodel->where_mail($email,$user->id);
			$this->session->set_userdata('user',$mail);

			$this->session->set_flashdata('profile', '<div class="alert alert-danger"><strong>'.$user->username.'Updated</strong></div>');


			redirect('profile');

	    	}
 
	    	else
	    	{
	    		
	    		$this->session->set_flashdata('profile', '<div class="alert alert-danger"><strong>Error</strong></div>');
	    		redirect('profile');
	    	}
	    } 

	    else
	    {
	    	$error = $this->upload->display_errors();
	    	$this->session->set_flashdata('upload', $error);
	    	redirect('profile');
	    	
	    }
	    }
       
	    else {
	    	
	    	$this->load->view('front/profile');
	    	//redirect('profile');
	    }
	}

}