<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Users extends CI_Controller
{
	public function index()
	{
		echo 'users';
	}

	public function register()
	{
		$this->load->library('form_validation');
	    $this->form_validation->set_rules(
        'username', 'Username',
        'required|min_length[5]|max_length[12]|is_unique[users.username]',
        array(
                'required'      => 'You have not provided %s.',
                'is_unique'     => 'This %s already exists.'
        )
);
	    $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
	    $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[1]');
	    $this->form_validation->set_rules('passconf', 'Password Confirmation', 'trim|required|matches[password]');


$this->form_validation->set_message('is_unique','<div class="alert alert-success"><strong>%s</strong></div>');
$this->form_validation->set_message('min_length','<div class="alert alert-danger"><strong> %s Check the length</strong></div>');
$this->form_validation->set_message('matches','<div class="alert alert-danger"><strong>Please Check %s Field</strong></div>');
	    

	    if ($this->form_validation->run()) {
	    	
	    	echo "checked";
	    }

	    else
	    {
	    	$this->load->view('front/front');
	    }



	}

}