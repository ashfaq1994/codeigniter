<?php

function session($type,$name,$message=null)
{
	$CI = get_instance();
	if ($type=='read') {

		return $CI->session->userdata($name);
	}

	if ($type=='yaz') {

		return $CI->session->userdata($name,$message);
	}
}

