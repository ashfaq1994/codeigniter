<?php $this->load->view('front/includes/header'); ?>
<?php $person = $this->session->userdata('user'); ?>
<div class="hero user-hero">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="hero-ct">
					<h1><?php echo $person->username; ?>’s profile</h1>
					<ul class="breadcumb">
						<li class="active"><a href="#">Home</a></li>
						<li> <span class="ion-ios-arrow-right"></span>Profile</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="page-single">
	<div class="container">
		<div class="row ipad-width">
			<div class="col-md-3 col-sm-12 col-xs-12">
				<div class="user-information">
					<div class="user-img">
						<a href="#"><img src="<?php echo $person->user_avatar;?>" alt="<?php echo $person->username; ?>"><br></a>
						<a href="#" class="redbtn">Change avatar</a>
					</div>
					<div class="user-fav">
						<p>Account Details</p>
						<ul>
							<li class="active"><a href="userprofile.html">Profile</a></li>
							<li><a href="userfavoritelist.html">Favorite movies</a></li>
							<li><a href="userrate.html">Rated movies</a></li>
						</ul>
					</div>
					<div class="user-fav">
						<p>Others</p>
						<ul>
							<li><a href="#">Change password</a></li>
							<li><a href="#">Log out</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-md-9 col-sm-12 col-xs-12">
				<?php if ($this->session->flashdata('upload')) {
					echo $this->session->flashdata('upload');
				} ?>
 				<div class="form-style-1 user-pro">
<form method="POST" action="<?php echo base_url('users/profile_update');?>" enctype="multipart/form-data">
						<h4>01. Profile details</h4>
						<div class="row">
							<div class="col-md-4 form-it">
								<label>Username</label>
								<input type="text" name="username" value="<?= $person->username; ?>">
							</div>
							<div class="col-md-4 form-it">
								<label>Email Address</label>
								<input type="email" name="email" value="<?= $person->email; ?>">
							</div>							
							<div class="col-md-4 form-it">
								<label>File</label>
								<input type="file" name="userfile" value="<?= $person->user_avatar; ?>">
							</div>
						</div>
						<div class="row">
							<div class="col-md-2">
								<input class="submit" type="submit" value="save">
							</div>
						</div>	
</form>

					<form action="" class="password">
						<h4>02. Change password</h4>
						<div class="row">
							<div class="col-md-6 form-it">
								<label>Old Password</label>
								<input type="text" placeholder="**********">
							</div>
						</div>
						<div class="row">
							<div class="col-md-6 form-it">
								<label>New Password</label>
								<input type="text" placeholder="***************">
							</div>
						</div>
						<div class="row">
							<div class="col-md-6 form-it">
								<label>Confirm New Password</label>
								<input type="text" placeholder="*************** ">
							</div>
						</div>
						<div class="row">
							<div class="col-md-2">
								<input class="submit" type="submit" value="change">
							</div>
						</div>	
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!--end of latest new v1 section-->
<?php $this->load->view('front/includes/footer'); ?>