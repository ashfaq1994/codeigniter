<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
class BlogController extends Controller
{
    //

    public function index()
    {
       echo $phone = User::all();
       echo '</br>';
       echo $phone = User::find(1)->phone;
       echo '</br>';
       echo $phone = User::find(2)->phone;
    }
}
