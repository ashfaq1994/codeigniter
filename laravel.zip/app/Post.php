<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Post extends Model
{
    use SoftDeletes;

     protected $fillable = ['title','content','feature','category_id','slug'];
     protected $dates = ['deleted_at'];
    

    public function getFeatureAttribute($feature)
    {
        return asset($feature);
    }

    public function category()
    {
       return $this->hasOne('App\Category');
    }
    
}
