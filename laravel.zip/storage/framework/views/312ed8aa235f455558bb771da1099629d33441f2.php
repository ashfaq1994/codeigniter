<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="card">
   <div class="card-header">Create a category</div>

   <div class="card-body">
       <form action="<?php echo e(route('category.store')); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
     <?php echo method_field('post'); ?>
            <div class="from-group">
               <label for="#title"> Title </label>
                <input name="name" type="text" class="form-control">
            </div>

             <div class="from-group mt-1">
                 <button type="submit" class="btn btn-success">submit</button>
             </div>
       </form>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>