<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
            <table class="table table-hover">
            <thead>
                <th>
                    Category Name
                </th>
                <th>
                    Editing
                </th>
                <th>
                    Deleting
                </th>
            </thead>
            <tbody>
             <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
                    <td>
                        <?php echo e($cat->name); ?>

                    </td>

                    <td>
                        <a href=" <?php echo e(route('category.edit', ['id' => $cat->id])); ?> " class="btn btn-info">Edit</a>
                    </td>
                    <td>
                            <a href=" <?php echo e(route('category.destroy', ['id' => $cat->id])); ?> " class="btn btn-danger">Delete</a>
                    </td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
                
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>