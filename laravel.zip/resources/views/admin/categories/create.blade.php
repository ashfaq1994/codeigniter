@extends('layouts.app')


@section('content')

@include('admin.includes.errors')

<div class="card">
   <div class="card-header">Create a category</div>

   <div class="card-body">
       <form action="{{route('category.store')}}" method="POST">
            @method('PUT')
            @csrf
     @method('post')
            <div class="from-group">
               <label for="#title"> Title </label>
                <input name="name" type="text" class="form-control">
            </div>

             <div class="from-group mt-1">
                 <button type="submit" class="btn btn-success">submit</button>
             </div>
       </form>
   </div>
</div>
@endsection