@extends('layouts.app')


@section('content')
<div class="card">
    <div class="card-body">
            <table class="table table-hover">
            <thead>
                <th>
                    Category Name
                </th>
                <th>
                    Editing
                </th>
                <th>
                    Deleting
                </th>
            </thead>
            <tbody>
             @foreach ($cats as $cat)
             <tr>
                    <td>
                        {{ $cat->name }}
                    </td>

                    <td>
                        <a href=" {{ route('category.edit', ['id' => $cat->id]) }} " class="btn btn-info">Edit</a>
                    </td>
                    <td>
                            <a href=" {{ route('category.destroy', ['id' => $cat->id]) }} " class="btn btn-danger">Delete</a>
                    </td>
                </tr>
             @endforeach
            </tbody>
        </table>
                
    </div>
</div>

@endsection