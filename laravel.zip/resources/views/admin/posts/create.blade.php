@extends('layouts.app')


@section('content')

@include('admin.includes.errors')

<div class="card">
        <div class="card-header">Create a new post</div>

   <div class="card-body">
       <form action="{{route('post.store')}}" method="POST" enctype="multipart/form-data">
            @method('PUT')
            @csrf
     @method('post')
            <div class="from-group">
               <label for="#title"> Title </label>
                <input name="title" type="text" class="form-control">
            </div>

            <div class="from-group">
                    <label for="#title"> Featured Image </label>
                     <input name="featuredimg" type="file" class="form-control">
             </div>

             <div class="form-group">
                 <label for="category">Select a Category</label>
                 <select name="category_id" id="" class="form-control">
                    @foreach ($categories as $category)
                        <option value="{{ $category->id }}">{{ $category->name }}</option>
                    @endforeach
                 </select>
             </div>

             <div class="from-group">
                    <label for="#title"> Content </label>
                  <textarea name="content" id="content" cols="5" rows="5" class="form-control"></textarea>
             </div>
             <div class="from-group mt-1">
                 <button type="submit" class="btn btn-success">submit</button>
             </div>
       </form>
   </div>
</div>
@endsection