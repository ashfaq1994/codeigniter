@extends('layouts.app')


@section('content')
<div class="card">
    <div class="card-body">
            <table class="table table-hover">
            <thead>
                <th>
                   Featured
                </th>
                <th>
                    Title
                </th>
                <th>
                    Edit
                </th>
                <th>
                    Delete
                </th>
            </thead>
            <tbody>
             @foreach ($posts as $post)
             <tr>
                    <td>
                     <img src="{{ $post->feature }}" alt="{{$post->title}}"  width="90px" height="90px">
                    </td>
                     
                    <td>
                        {{ $post->title }}
                    </td>
                    <td>
                         Edit {{-- <a href=" {{ route('category.edit', ['id' => $cat->id]) }} " class="btn btn-info">Edit</a> --}}
                    </td>

                    <td>
                        Delete
                    </td>
                </tr>
             @endforeach
            </tbody>
        </table>
                
    </div>
</div>

@endsection